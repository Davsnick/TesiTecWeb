from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import Group
from django import forms
from .models import UserProfile, Message, Post, Chat


class CreateReader(UserCreationForm):

    def save(self, commit=True):
        user = super().save(commit)
        readers = Group.objects.get(name='Readers')
        readers.user_set.add(user)
        return user
    
class CreatePublisher(UserCreationForm):

    def save(self, commit=True):
        user = super().save(commit)
        publishers = Group.objects.get(name='Publishers')
        publishers.user_set.add(user)
        return user
    
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = [
            'first_name',
            'last_name',
            'city',
            'email',
            'phone_number',
            'profession',
            'education',
            'bio',
        ]

class MessageForm(forms.ModelForm):
    content = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}))

    class Meta:
        model = Message
        fields = ['content']

    def clean_content(self):
        content = self.cleaned_data.get('content')
        if not content:
            raise forms.ValidationError("Il messaggio non può essere vuoto.")
        return content

class CreateChatForm(forms.ModelForm):
    class Meta:
        model = Chat
        fields = ['participants']

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'text', 'external_link']


