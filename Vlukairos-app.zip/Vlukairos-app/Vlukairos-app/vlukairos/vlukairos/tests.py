from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse
from .models import Post

class CreatePostTestCase(TestCase):
    def setUp(self):
        # Creo un utente di esempio
        self.user = User.objects.create_user(
            username='testuser',
            password='testpassword'
        )

    def test_create_post(self):
        # Effettuo l'accesso come l'utente di test
        self.client.login(username='testuser', password='testpassword')

        # Creo un post utilizzando la vista
        response = self.client.post(reverse('create_post'), {
            'title': 'Test Post',
            'text': 'This is a test post.',
            'external_link': 'https://example.com'
        })

        # Verifico che la risposta reindirizzi alla pagina corretta dopo la creazione del post
        self.assertRedirects(response, reverse('posts'))

        # Verifico che il post sia stato creato nel database
        self.assertTrue(Post.objects.filter(title='Test Post', text='This is a test post.').exists())

    def tearDown(self):
        # Eseguo le operazioni di "clean up" qui
        # Elimina gli oggetti creati durante i test
        User.objects.filter(username='testuser').delete()
        Post.objects.filter(title='Test Post').delete()
