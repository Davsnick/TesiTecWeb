from django.db import models
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User

User = get_user_model()

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    followers = models.ManyToManyField(User, related_name='following', blank=True)

    first_name = models.CharField(max_length=50, blank=True, null=True)
    last_name = models.CharField(max_length=50, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    profession = models.CharField(max_length=100, blank=True, null=True)
    education = models.CharField(max_length=100, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    class Meta:
        app_label = 'vlukairos'

    def __str__(self):
        return self.user.username

class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100, null=False, default='New Post!')
    text = models.TextField()
    pub_date = models.DateTimeField(auto_now_add=True)
    external_link = models.URLField(blank=True, null=True)

    def __str__(self):
        return f'Post by {self.author.username} on {self.pub_date}'

class Chat(models.Model):
    participants = models.ManyToManyField(User, related_name='chats', limit_choices_to={'chats__count__lte': 2})

    def __str__(self):
        return self.get_participant_names()

    def get_participant_names(self):
        return ', '.join([str(participant) for participant in self.participants.all()])

class Message(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    chat_room = models.ForeignKey(Chat, on_delete=models.CASCADE, related_name='messages', blank=True, null=True)

    def __str__(self):
        #return f'Message by {self.author.username} at {self.timestamp}'
        return str(self.id)

