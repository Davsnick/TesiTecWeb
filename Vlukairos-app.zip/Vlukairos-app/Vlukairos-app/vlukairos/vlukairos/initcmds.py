# import models of cbv

def erase_db():
    print('Erasing db...')
    #Content.objects.all().delete()
    print('Db erased!')

    