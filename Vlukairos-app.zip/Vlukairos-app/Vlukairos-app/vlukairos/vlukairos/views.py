from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic.edit import CreateView
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model, login  # Importa il modello utente
from django.urls import reverse_lazy, reverse
from .forms import *
from .models import UserProfile, Message, Chat
import logging

from django.contrib.auth.views import LogoutView
from django.contrib.messages import add_message, constants, info, success

logger = logging.getLogger(__name__)
User = get_user_model()  # Ottieni il modello utente


# home.html
def home(request):

    if not request.user.is_authenticated:
        logger.warning(str(request.user) + ' not authenticated!')

    recent_posts = Post.objects.order_by('-pub_date')[:20]

    text = """Welcome to our cozy corner of the internet, where the mind meets the heart! 🌟
    
    Are you tired of the noise and chaos of the online world? Looking for a peaceful oasis to dive into meaningful conversations about science, literature, art, and all things happening around us? Look no further! 📚🎨🌍
    
    Join our friendly community, where we celebrate the beauty of intellectual exchange. Here, we value the art of constructive dialogue and cherish every idea that sparks curiosity. 💡
    
    Whether you're into scientific discoveries, passionate prose, captivating art, or the latest buzz in the world, we've got you covered. It's all about sharing and caring here, so come on in, kick back, and let's explore the world of thoughtful discussions together! 🤝💬✨
    
    Join us today and be part of something truly special. See you on the flip side! 😉🌈 #DigitalTranquility"""

    context = {
        "title": "Vlukairos",
        "recent_posts": recent_posts,
        "text": text
    }
    return render(request, "home.html", context)

# aboutus.html
def about(request):

    text = """We are individuals who seek beauty wherever it reveals itself. Indeed, we find it beautiful to engage in conversations over a good cup of coffee about relationships, existence, science, perspectives on the common good, and ways of being.
    
    We embrace the value in the favorable time of the habitat we share, for we are not alone – neither I, Lorenzo, nor Niccolò. We are convinced that only together can we make this world beautiful. It is through writing that we can persuade others of the beauty within the insecure young person seeking answers to questions not yet fully formed.
    
    The person who reevaluates their existence, seeking unity in the daily fragmentation of commitments and expectations. Speaking is a language gifted to us at birth. Fortunately, it is not merely for uttering words but primarily for pre-telling a beautiful expectation of existence.
    
    Writing to listen, pre-telling to allow the existence of possibilities, announcing to prevent something from happening, and engaging in debates to foster a context for seeking the truth.
    
    Yes, because truth and beauty are also synonymous with goodness. Thank you for enriching the favorable times of our existence with value. VluKairos strives to make our sense of belonging a compelling appeal! In conscience, I say YES!
    
    Of course, there is also the analysis of reality following cultural events like '68 in Italy, the fall of the Berlin Wall, and we feel somewhat stunned by this emotional instability and challenging times. The year 2001 marked the beginning of terrorism as a mass social phenomenon, in 2008 with the recessionary dynamics we endured, and finally, the great pandemic of our century, COVID-19. We cannot remain unchanged in the face of an ever-changing existence.
    
    We are the co-creators of this reality. The web of relationships we weave is not interchangeable because it forms the foundation of our identity, our way of being, but it is also the tie that weighs our daily struggles and anxieties.
    
    I am grateful for this reality before me. We are convinced that only enlightened ignorance can preserve the privilege of truth through intellectual honesty. It makes something possible. We are convinced that only respect for people can be the key to discovering the reality that lies ahead. We are convinced that existence is a struggle for something meaningful. It makes something possible...
    
    We are convinced that we can change this world from the very core – starting with ourselves! Yes, because that's what you intended even before I was born...

    We are a duo, open to discovering and including in this common architecture, which seems diabolically welcoming, the beam of your decisions: do I write or not, do I interact or not, do I want to participate in the organization or just benefit from it, do I want to change worlds or just my own with others?

    We proclaim that the future is now! But perhaps now is the time to write beautifully.

    Enjoy the conversation! 🌟"""

    context = {
        "title": "About Us",
        "text": text
    }
    return render(request, "aboutus.html", context)

# profile.html
def profile(request):

    if not request.user.is_authenticated:
        # L'utente non è autenticato
        return render(request, "profile.html")

    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            success(request, 'Profile updated successfully!')
            return redirect('profile')
    else:
        form = UserProfileForm(instance=user_profile)

    followed_users = user_profile.user.following.all()
    total_following = followed_users.count()

    context = {
        "title": "Profile",
        'form': form,
        "total_following": total_following
    }
    return render(request, "profile.html", context)

# settings.html
def settings(request):

    text = """
    The Vlukairos development team reserves the right to insert future settings aimed at customizing and improving the user experience of the application, hoping that its users will continue to use and support it to the fullest.
    """
    context = {
        "title": "Settings",
         "text": text
    }
    return render(request, "settings.html", context)

class UserCreateView(CreateView):

    form_class = CreateReader
    template_name = "registration/signin.html"
    success_url = reverse_lazy("login")

    def form_valid(self, form):
        response = super().form_valid(form)
        
        # Crea l'oggetto UserProfile associato all'utente appena creato
        UserProfile.objects.create(user=self.object)
        
        # Effettua il login dell'utente
        login(self.request, self.object)
        
        return response


class CustomLogoutView(LogoutView):
    def dispatch(self, request, *args, **kwargs):
        # messaggio flash
        info(self.request, "You have successfully logged out, see you soon!")

        return super().dispatch(request, *args, **kwargs)


@login_required
def follow_user(request, username):
    user_to_follow = get_object_or_404(User, username=username)
    user_profile = UserProfile.objects.get(user=user_to_follow)

    if user_to_follow != request.user:
        user_profile.followers.add(request.user)

    return redirect('user_profile', username=username)

@login_required
def unfollow_user(request, username):
    user_to_unfollow = get_object_or_404(User, username=username)
    user_profile = UserProfile.objects.get(user=user_to_unfollow)

    if user_to_unfollow != request.user:
        user_profile.followers.remove(request.user)

    return redirect('user_profile', username=username)


# followed_users_list.html
@login_required
def followed_users_list(request):
    user_profile = UserProfile.objects.get(user=request.user)  # Recupera il profilo dell'utente autenticato
    followed_users = user_profile.user.following.all() 
    total_following = followed_users.count()
    context = {'followed_users': followed_users,
               'total_following': total_following}
    return render(request, 'profile_navbar/followed_users_list.html', context)


# followers_list.html
@login_required
def followers_list(request):
    user_profile = UserProfile.objects.get(user=request.user)  # Recupera il profilo dell'utente autenticato
    followers = user_profile.followers.all()
    total_followers = followers.count()
    context = {'followers': followers,
               'total_followers': total_followers}
    return render(request, 'profile_navbar/followers_list.html', context)


# messages.html
@login_required
def messages(request):
    # Ottieni tutte le chat iniziate dall'utente loggato
    user_chats = Chat.objects.filter(participants=request.user).reverse()

    context = {'user_chats': user_chats}
    return render(request, 'profile_navbar/messages.html', context)


@login_required
def send_message(request, chat_id):
    # Ottenere la chat corrispondente o generare un errore 404 se non esiste
    chat = get_object_or_404(Chat, id=chat_id)


    if request.method == 'POST':
        # Ottenere l'autore (utente loggato)
        author = request.user

        # Ottenere il contenuto del messaggio dal form o da altri mezzi
        content = request.POST.get('content')

        # Creare il messaggio con autore e contenuto
        message = Message(author=author, text=content, chat_room=chat)
    
        # Salvare il messaggio nel database
        message.save()

        # Effettuare un reindirizzamento alla pagina di dettaglio della chat
        return redirect('chat_detail', chat_id=chat_id)
    
    # Se la richiesta non è di tipo POST, gestisci la visualizzazione del form
    return render(request, 'profile_navbar/messages.html', {'chat': chat})


@login_required
def create_chat(request, participant1_id, participant2_id):
    # Ottieni gli oggetti User corrispondenti agli ID dei partecipanti
    participant1 = get_object_or_404(User, id=participant1_id)
    participant2 = get_object_or_404(User, id=participant2_id)

    # Crea una nuova chat con i due partecipanti
    chat = Chat.objects.create()
    chat.participants.add(participant1, participant2)

    # Reindirizza alla pagina chat_detail della chat appena creata
    return redirect('chat_detail', chat_id=chat.id)

# chat_detail.html
@login_required
def chat_detail(request, chat_id):
    # Ottieni la chat specifica utilizzando l'ID
    chat = get_object_or_404(Chat, id=chat_id)

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            # Ottenieni l'autore (utente loggato)
            author = request.user

            # Crea il messaggio con autore e contenuto
            message = Message(author=author, text=form.cleaned_data['content'], chat_room=chat)
    
            # Salva il messaggio nel database
            message.save()

            # Effettua un reindirizzamento alla stessa pagina di dettaglio della chat
            return redirect('chat_detail', chat_id=chat_id)
    else:
        form = MessageForm()

    # Ottieni tutti i messaggi associati a questa chat
    messages = Message.objects.filter(chat_room=chat).order_by('-timestamp')

    context = {'chat': chat, 'form': form, 'messages': messages}
    return render(request, 'chat_detail.html', context)


# user_profile.html
def user_profile(request, username):
    # Ottieni l'oggetto User associato al nome utente
    user = get_object_or_404(User, username=username)

    # Ottieni l'utente loggato
    current_user = request.user

    # Verifica se esiste già una chat tra l'utente loggato e l'utente del profilo
    existing_chat = Chat.objects.filter(participants=current_user).filter(participants=user).first()

    # Ottieni il profilo dell'utente
    user_profile = UserProfile.objects.get(user=user)

    context = {
        'user_profile': user_profile,
        'existing_chat': existing_chat
    }

    return render(request, 'user_profile.html', context)


# create_post.html
@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user  # Imposta l'autore come utente registrato
            post.save()
            return redirect('posts')
    else:
        form = PostForm()

    context = {'form': form}
    return render(request, 'create_post.html', context)


@login_required
def posts(request):
    # Ottieni i post pubblicati dall'utente loggato e ordinali per data di pubblicazione decrescente
    user_posts = Post.objects.filter(author=request.user).order_by('-pub_date')

    context = {'user_posts': user_posts}
    return render(request, 'posts.html', context)